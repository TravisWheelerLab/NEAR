from .my_rust_module import *

__doc__ = my_rust_module.__doc__
if hasattr(my_rust_module, "__all__"):
    __all__ = my_rust_module.__all__